import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_absolute_error

# Load dataset
df = pd.read_csv("data/sample_data.csv")

# Features & Target
X = df.drop("Price", axis=1)
y = df["Price"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model training
model = LinearRegression()
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Evaluation
print(f"R² Score: {r2_score(y_test, y_pred)}")
print(f"Mean Absolute Error: {mean_absolute_error(y_test, y_pred)}")

# Example prediction
sample = [[2000, 3, 2, 1]]  # Example: 2000 sq ft, 3 bedrooms, 2 bathrooms, location code 1
predicted_price = model.predict(sample)
print(f"Predicted Price: ₹ {predicted_price[0]:,.0f}")
