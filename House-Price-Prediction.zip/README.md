# 🏠 House Price Prediction

A machine learning project that predicts house prices based on features like area, bedrooms, location, etc.

## 📌 Features
- Data preprocessing (handling missing values, encoding, scaling)
- Model training using Linear Regression
- Evaluation using R² score and Mean Absolute Error
- Predictions on new data

## 📂 Dataset
The dataset contains:
- `Area` (in sq ft)
- `Bedrooms`
- `Bathrooms`
- `Location`
- `Price`

## 🚀 How to Run
1. Clone this repository:
   ```bash
   git clone https://github.com/YourUsername/House-Price-Prediction.git
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the script:
   ```bash
   python house_price_prediction.py
   ```

## 🛠 Requirements
See `requirements.txt` for dependencies.

## 📊 Example Output
```
Predicted Price: ₹ 45,23,000
```

⭐ **Made with ❤️ by [Gouri Sunil Kumar](https://github.com/GOURI0630)**
